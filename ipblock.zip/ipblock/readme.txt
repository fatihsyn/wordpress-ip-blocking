It's very easy to ban ip in WordPress! You can automatically block ip by installing the plugin within 5 seconds.

Contact: info@fatihsayin.com.tr
Web: https://fatihsayin.com.tr / https://fatihsayin.de